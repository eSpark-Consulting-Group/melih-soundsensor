TEMPLATE = subdirs

SUBDIRS += tests

